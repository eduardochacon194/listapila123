package app;

import Pilas.Pilas;
import node.node;

public class App {
	
	@SuppressWarnings("unchecked")
	public static <T> void main(String[] args) {
		// TODO Auto-generated method stub
		Pilas<String> names    = new Pilas<String>(5);
	
		names.Push("Ana");
		names.Push("Ricardo");
		names.Push("Jose Arturo");
		names.Push("Manuel");
		names.Push("Esteban");
		
		node<T> nodo;
		for(String string: names)
		{
			System.out.println(string);
		}
		
		System.out.println("---------  Pop  ---------");
		names.Pop();
		
		
		System.out.println("---------  Peek  ---------");
		nodo=(node<T>) names.peek();
		if(nodo!=null) System.out.println(nodo.getValue());
		
	
		System.out.println("---------  Pop  ---------");
		names.Pop();
		
		
		System.out.println("--------- Search ---------");
		nodo=(node<T>) names.search("Ricardo");
		if(nodo!=null) System.out.println(nodo.getValue());
		
		System.out.println("---------------- Iterador -------------------");
		for(String string: names)
		{
			System.out.println(string);
		}
		
		System.out.println("---------------- Clear -------------------");
		names.clear();
		
		
		for(String string: names)
		{
			System.out.println(string);
		}
		
	}
}