package Pilas;
import java.awt.print.PrinterAbortException;
import java.util.ArrayList;
import java.util.Iterator;

import node.node;
public class Pilas<T extends Comparable<T>> implements Iterable<T> {
	private node<T> sentinel=null, top=null;
	private int tamaoPila=0;
	static public int tamao=0;
	
	public Pilas(int tamaoPila){
		top= new node<T>();
		sentinel = new node<T>();
		sentinel.setIndex(-1);
		this.tamaoPila=tamaoPila;
	}
	public Pilas(T value, int tamaoPila) {
		this(tamaoPila);
		node<T> tmp = new node<T>(value);
		tmp.setIndex(0);
		sentinel.setNext(tmp);
		this.tamaoPila=tamaoPila;
	}
	public void Push(T value) {
		if(!isfull())
		{
			node<T>tmp =sentinel;
			while (tmp.getNext()!=null) 
				tmp = tmp.getNext();
			tmp.setNext(new node<T>(value));
			top.setValue(value);
			tamao++;
		}
	}
	public boolean isEmpty()
	{
		if (sentinel.getNext()==null)return true;
		else return false;
		
	}
	public node<T> search(T value)
	{
		return search(value,sentinel);
	}
	public node<T> search(T value, node<T> lista)
	{
		if (lista.getNext()==null)return null;
		if(lista.getNext().getValue().equals(value))return lista.getNext(); 
		return search(value, lista.getNext());
	}
	public node<T> peek() {
		if(!isEmpty())
		{
			node<T> tmp = sentinel;
			while (tmp.getNext()!=null) {
				tmp = tmp.getNext();
			}
			System.gc();
			return tmp;
		}
		return null;
	}
	public void Pop()
	{	
		node<T> tmp=sentinel;
		if(!isEmpty())
		{
			if (tmp.getNext().getValue().equals(top.getValue())) {
				System.out.println(top.getValue());
				sentinel.setNext(null);
			}else {
				while(tmp.getNext().getNext()!=null)
				{
					if(tmp.getNext().getNext().getValue().equals(top.getValue()))
					{
						tmp=tmp.getNext();
						System.out.println(top.getValue().toString());
						top.setValue(tmp.getValue());
						tmp.setNext(null);
						tamao--;
						return;
					}
					tmp=tmp.getNext();
				}
			}
		}
			///////////////////////////////////////////////////////////////////////
			///////////////////////////////////////////////////////////////////////
	}
	public int size()
	{
		return tamao;
	}
	public void clear()
	{
		node<T> tmp = sentinel;
		if(tmp.getNext() != null) tmp.setNext(null);
		System.gc();
	}
	public boolean isfull()
	{
		int s=size();
		if(s==tamaoPila) return true;
		else return false;
	}
	public void pronter() {
		node<T> tmp = sentinel;
		while (tmp.getNext()!=null) {
			tmp = tmp.getNext();
			System.out.println(tmp.getValue());
		}
		System.gc();
	}
	@Override
	public Iterator<T> iterator(){
		return new Iterator<T>() {
			node<T> tmp=sentinel;
			@Override
			public boolean hasNext() {
				tmp=tmp.getNext();
				return(tmp != null)?true:false;	
			}
			@Override
			public T next() {
				return tmp.getValue();
			}
		};
	}
}